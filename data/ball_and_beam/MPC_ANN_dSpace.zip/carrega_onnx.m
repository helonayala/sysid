clc; clear;

onnxFile = "ann_model_scaled_opset14.onnx";

net = importNetworkFromONNX(onnxFile, ...
    "InputDataFormats", "C", ...
    "OutputDataFormats", "C");

x_test = single(zeros(1,15));
u_test = predict(net, x_test);

disp(u_test)

save("net_mpc.mat", "net")