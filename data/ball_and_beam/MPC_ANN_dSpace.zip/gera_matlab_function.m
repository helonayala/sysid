clc
clear
% 1. Carregar a rede importada do ONNX
load('net_mpc.mat', 'net');

% 2. Nome do arquivo da MATLAB Function que será gerado
outputFileName = 'minha_rede_autogen.m';
fid = fopen(outputFileName, 'w');

% 3. Escrever o cabeçalho da função MATLAB
fprintf(fid, 'function u = minha_rede_autogen(x_in)\n');
fprintf(fid, '    %%#codegen\n\n');
fprintf(fid, '    %% Garante o formato estável de vetor coluna [15x1] para o dSpace\n');
fprintf(fid, '    x_in_ready = x_in(:);\n\n');

% Contadores para controlar o fluxo das variáveis internas
layerIdx = 1;
activationCount = 0;
currentInputVar = 'x_in_ready';

disp('--- Iniciando mapeamento rigoroso de camadas ---');

% 4. Varrer absolutamente TODAS as camadas
for i = 1:numel(net.Layers)
    layer = net.Layers(i);
    layerClass = class(layer);
    
    fprintf('Processando Camada %d/%d: "%s" [%s]\n', i, numel(net.Layers), layer.Name, layerClass);
    
    % --- CASO 1: CAMADA DE ENTRADA (Apenas pula, já tratada no cabeçalho) ---
    if isa(layer, 'nnet.cnn.layer.FeatureInputLayer') || contains(layerClass, 'FeatureInputLayer')
        continue;
        
    % --- CASO 2: CAMADAS DE SCALING / ELEMENT-WISE (Sub, Div, Mul, Add do ONNX) ---
    elseif contains(layerClass, 'ScalingLayer') || contains(layerClass, 'Elementwise') || ...
           contains(layer.Name, 'x_Sub') || contains(layer.Name, 'x_Div')
        
        % Extração genérica e segura de Scale e Bias do grafo do ONNX
        scaleVal = ones(15, 1);
        biasVal = zeros(15, 1);
        
        if isprop(layer, 'Scale'), scaleVal = layer.Scale; end
        if isprop(layer, 'Bias'), biasVal = layer.Bias; end
        if isprop(layer, 'Offset'), biasVal = layer.Offset; end
        
        % Conversão para numérico puro (caso seja dlarray)
        if ismethod(scaleVal, 'extractdata'), scaleVal = extractdata(scaleVal); end
        if ismethod(biasVal, 'extractdata'), biasVal = extractdata(biasVal); end
        scaleVal = scaleVal(:);
        biasVal = biasVal(:);
        
        fprintf(fid, '    %% --- Camada de Ajuste de Escala: %s ---\n', layer.Name);
        fprintf(fid, '    scale_%d = [\n', i);
        for row = 1:numel(scaleVal)
            fprintf(fid, '        %s;\n', num2str(scaleVal(row), '%0.16g'));
        end
        fprintf(fid, '    ];\n');
        
        fprintf(fid, '    bias_%d = [\n', i);
        for row = 1:numel(biasVal)
            fprintf(fid, '        %s;\n', num2str(biasVal(row), '%0.16g'));
        end
        fprintf(fid, '    ];\n\n');
        
        nextVar = sprintf('x_scaled_%d', i);
        fprintf(fid, '    %s = ( %s .* scale_%d ) + bias_%d;\n\n', nextVar, currentInputVar, i, i);
        currentInputVar = nextVar;
        
    % --- CASO 3: TOTALMENTE CONECTADA (Dense / Fully Connected) ---
    elseif isa(layer, 'nnet.cnn.layer.FullyConnectedLayer') || contains(layerClass, 'FullyConnected')
        
        W = layer.Weights; 
        b = layer.Bias;
        
        if ismethod(b, 'extractdata'), b = extractdata(b); end
        b = b(:);
        if ismethod(W, 'extractdata'), W = extractdata(W); end
        
        fprintf(fid, '    %% --- Camada %d: Fully Connected (%s) ---\n', layerIdx, layer.Name);
        fprintf(fid, '    W%d = [\n', layerIdx);
        for row = 1:size(W, 1)
            fprintf(fid, '        %s;\n', num2str(W(row, :), '%0.16g '));
        end
        fprintf(fid, '    ];\n\n');
        
        fprintf(fid, '    b%d = [\n', layerIdx);
        for row = 1:size(b, 1)
            fprintf(fid, '        %s;\n', num2str(b(row), '%0.16g'));
        end
        fprintf(fid, '    ];\n\n');
        
        nextVar = sprintf('z%d', layerIdx);
        fprintf(fid, '    %s = W%d * %s + b%d;\n\n', nextVar, layerIdx, currentInputVar, layerIdx);
        
        currentInputVar = nextVar;
        layerIdx = layerIdx + 1;
        
    % --- CASO 4: ATIVAÇÃO RELU ---
    elseif isa(layer, 'nnet.cnn.layer.ReLULayer') || contains(layerClass, 'ReLU')
        activationCount = activationCount + 1;
        nextVar = sprintf('a%d', activationCount);
        fprintf(fid, '    %% Ativação ReLU\n');
        fprintf(fid, '    %s = max(0, %s);\n\n', nextVar, currentInputVar);
        currentInputVar = nextVar;
        
    % --- CASO 5: ATIVAÇÃO TANH ---
    elseif isa(layer, 'nnet.cnn.layer.TanhLayer') || contains(layerClass, 'Tanh')
        activationCount = activationCount + 1;
        nextVar = sprintf('a%d', activationCount);
        fprintf(fid, '    %% Ativação Tanh\n');
        fprintf(fid, '    %s = tanh(%s);\n\n', nextVar, currentInputVar);
        currentInputVar = nextVar;
        
    % --- CASO STOPIER / SEGURANÇA: Se houver qualquer camada desconhecida, mata o script ---
    else
        fclose(fid);
        delete(outputFileName); % Apaga o arquivo incompleto para evitar uso errado
        error('ERRO CRÍTICO: A camada "%s" do tipo [%s] não foi mapeada no gerador! Script interrompido para segurança.', ...
            layer.Name, layerClass);
    end
end

% 5. Finalizar escrevendo a saída
fprintf(fid, '    %% Definição da saída final\n');
fprintf(fid, '    u = %s'';\n', currentInputVar);
fprintf(fid, 'end\n');

fclose(fid);
disp('------------------------------------------------');
disp('Sucesso total! Todas as camadas processadas de ponta a ponta.');
disp(['Código gerado pronto para o dSpace: ', outputFileName]);