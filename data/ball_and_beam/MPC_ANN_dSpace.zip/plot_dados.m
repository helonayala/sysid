clc
clear
close all

load aquisicao_02_mpc_modelo_NARX.mat

t = aquisicao_02_mpc_modelo_NARX.X.Data;
u = aquisicao_02_mpc_modelo_NARX.Y(1).Data;
y2 = aquisicao_02_mpc_modelo_NARX.Y(2).Data;
y3 = aquisicao_02_mpc_modelo_NARX.Y(3).Data;

figure

subplot(2,1,1)
plot(t,u)
legend('control')

subplot(2,1,2)
plot(t,y2,t,y3,'r')
legend('output','reference')

